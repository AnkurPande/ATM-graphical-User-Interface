
public enum AccountType {
	checking, savings, loan, investment, creditCard;
}
