
public enum TransactionType {
	debit, credit, transfer;
}
